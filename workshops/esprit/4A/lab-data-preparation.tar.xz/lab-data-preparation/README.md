# Lab Data Preparation

- [Lab Data Preparation](#lab-data-preparation)
  - [Overview](#overview)
  - [Quickstart](#quickstart)

## Overview

Warm up :)

## Quickstart

```bash
# Create a virtual environment
uv venv

# Activate virtual environment
. .venv/bin/activate

# Update the project's environment
uv sync

# Create ipykernel
python -m ipykernel install \
  --user \
  --name lab-data-preparation-kernel \
  --display-name "lab-data-preparation-kernel"
```
