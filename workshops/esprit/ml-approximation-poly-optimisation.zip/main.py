from types import LambdaType
import numpy as np
import matplotlib.pyplot as plt
from numpy.polynomial import Polynomial


def matrice(X, p):
    n = len(X)
    A = np.zeros((n, p + 1))
    for j in np.arange(0, p + 1):
        A[:, j] = X[:, 0] ** j
    return A


def regression(X, Y, p):
    A = matrice(X, p)
    return np.linalg.inv(np.transpose(A).dot(A)).dot((np.transpose(A).dot(Y[:, 0])))


def gradient_descent(X, Y, p, Lambda0, eta, epsilon, max_iter):
    # Construire la matrice du modèle
    A = matrice(X, p)
    # Initialisation des coefficients et de l’historique
    Lambda = Lambda0.copy()
    J_hist = []
    Grad_hist = []
    max_iter += 1
    while --max_iter:
        # Calculer le gradient
        gradient = 2 * (A.T @ ((A @ Lambda) - Y[:, 0]))
        J_hist.append(gradient)

        # Mettre à jour les coefficients
        Lambda -= eta * gradient

        # Calculer la fonction coût
        J = np.linalg.norm(A @ Lambda - Y[:, 0]) ** 2
        J_hist.append(J)

        # Critère d’arrêt
        if np.linalg.norm(gradient) < epsilon:
            break
    return Lambda, J_hist, Grad_hist


def main():
    X, Y, p = np.array([[-1], [0], [1]]), np.array([[2], [1], [-1]]), 2
    _l = regression(X, Y, p)
    pol = Polynomial(_l)

    Lambda0, eta, epsilon, max_iter = np.zeros(p + 1), 1e-3, 1e-4, 10**4
    Lambda, J_hist, Grad_hist = gradient_descent(
        X, Y, p, Lambda0, eta, epsilon, max_iter
    )

    plt.scatter(X, Y, color="red", label="Données")
    plt.plot(X, pol(X))
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title("Regression Linéaire")
    plt.legend()
    plt.grid(visible=True)
    plt.show()


if __name__ == "__main__":
    main()
